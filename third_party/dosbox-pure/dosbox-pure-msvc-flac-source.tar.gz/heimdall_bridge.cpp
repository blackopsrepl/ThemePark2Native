/*
 * Small, read-only bridge between the embedded DOS machine and its native
 * host. DOSBox Pure is compiled into the same executable, so these functions
 * do not create an ABI, DLL, or extra runtime dependency.
 *
 * The host uses the bridge to inspect Heimdall 2's retained debug symbols and
 * measure engine state. Writes remain in game-specific host code where they
 * can be validated, documented, and disabled per room.
 */
#include "include/cpu.h"
#include "include/dos_inc.h"
#include "include/mem.h"
#include "include/vga.h"
#include <string.h>

extern const char *RunningProgram;

extern "C" unsigned char *heimdall2_guest_memory() { return MemBase; }

extern "C" unsigned short heimdall2_guest_psp() { return dos.psp(); }

extern "C" unsigned short heimdall2_guest_code_segment() {
  return SegValue(cs);
}

extern "C" unsigned short heimdall2_guest_data_segment() {
  return SegValue(ds);
}

extern "C" unsigned int heimdall2_guest_palette_rgb(unsigned int index) {
  if (index >= 256)
    return 0xFF000000u;
  const RGBEntry &color = vga.dac.rgb[index];
  const unsigned int maximum = (1u << vga.dac.bits) - 1u;
  const unsigned int red = color.red * 255u / maximum;
  const unsigned int green = color.green * 255u / maximum;
  const unsigned int blue = color.blue * 255u / maximum;
  return 0xFF000000u | (red << 16) | (green << 8) | blue;
}

extern "C" bool heimdall2_guest_game_is_running() {
  // DOS derives this eight-character name from the active PSP. Keeping the
  // comparison inside the bridge prevents the native host from depending on
  // DOSBox's internal global variables or headers.
  return RunningProgram && _stricmp(RunningProgram, "H2PC") == 0;
}
