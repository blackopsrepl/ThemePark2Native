#pragma once

#include "include/dosbox.h"

// Selects the row width used by the reviewed low-resolution drawing code.
// The executable imported from the CD reserves the larger pages permanently,
// but fixed 320x200 menus still need the original stride while they are drawn.
// Zero means success; a positive value identifies the validation that failed.
unsigned int themepark_set_low_layout(Bitu imageBase, Bitu setupPhysical,
                                      unsigned int width);
