/*
 * Narrow bridge between the embedded DOS runtime and the Windows host.
 *
 * This stable version deliberately exposes no engine-framebuffer patching.
 * Theme Park renders its original VGA/VESA images, and the native renderer
 * handles only presentation, scaling, input, audio, and application lifetime.
 */
#include "include/mem.h"
#include "include/vga.h"
#include <string.h>

extern const char *RunningProgram;

// The native host owns the original INTRO.EXE -> MAIN.EXE sequence. These
// commands are internal strings, so the player never sees a BAT file or shell.
extern "C" const char *themepark_native_launch_commands(const char *program) {
  if (program && _stricmp(program, "INTRO.EXE") == 0)
    return "intro.exe -C:/\nmain.exe -cC:/ -dC:/ -l0";
  if (program && _stricmp(program, "MAIN.EXE") == 0)
    return "main.exe -cC:/ -dC:/ -l0";
  return nullptr;
}

extern "C" unsigned char *themepark_guest_memory() { return MemBase; }

extern "C" unsigned int themepark_guest_memory_size() {
  return MEM_TotalPages() * 4096u;
}

extern "C" unsigned int themepark_guest_palette_rgb(unsigned int index) {
  if (index >= 256)
    return 0xFF000000u;
  const RGBEntry &colour = vga.dac.rgb[index];
  const unsigned int maximum = (1u << vga.dac.bits) - 1u;
  return 0xFF000000u | (colour.red * 255u / maximum << 16) |
         (colour.green * 255u / maximum << 8) |
         colour.blue * 255u / maximum;
}

extern "C" bool themepark_guest_main_is_running() {
  return RunningProgram && _stricmp(RunningProgram, "MAIN") == 0;
}

extern "C" bool themepark_guest_game_is_running() {
  if (!RunningProgram)
    return false;
  return _stricmp(RunningProgram, "MAIN") == 0 ||
         _stricmp(RunningProgram, "INTRO") == 0;
}

extern "C" bool themepark_guest_frame_is_renderable() {
  // The shell, DOSBox welcome page, and DOS/4GW banner use text mode. Keeping
  // text frames behind native loading art makes the compatibility layer
  // invisible while preserving every genuine game graphics frame.
  return themepark_guest_game_is_running() && vga.mode != M_TEXT;
}
