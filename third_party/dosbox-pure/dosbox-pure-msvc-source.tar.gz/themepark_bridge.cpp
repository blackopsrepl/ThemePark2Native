/*
 * Tiny read-only bridge between DOSBox Pure and the native application.
 *
 * DOSBox keeps the current DOS program name internally. Exposing one boolean
 * here lets the Windows host distinguish a normal return to the shell from a
 * running game without making host code include DOSBox implementation headers.
 */
#include "include/mem.h"
#include "include/regs.h"
#include "include/vga.h"
#include "themepark_layout.h"
#include <string.h>
#include <vector>

extern const char *RunningProgram;

namespace {
const Bitu kUnknownImageBase = ~(Bitu)0;
Bitu gThemeParkImageLinearBase = kUnknownImageBase;
Bitu gThemeParkSetupPhysical = kUnknownImageBase;
unsigned int gThemeParkWidescreenStatus = 0;
unsigned int gThemeParkScreenState = 0xFFFFFFFFu;
}

// The native host launches the original programs without a BAT file. These
// commands live inside the monolithic executable, so no DOS-facing launcher is
// created in the player's data directory.
extern "C" const char *themepark_native_launch_commands(const char *program) {
  if (program && _stricmp(program, "INTRO.EXE") == 0)
    return "intro.exe -C:/\nmain.exe -cC:/ -dC:/ -l0";
  if (program && _stricmp(program, "MAIN.EXE") == 0)
    return "main.exe -cC:/ -dC:/ -l0";
  return nullptr;
}

extern "C" unsigned char *themepark_guest_memory() { return MemBase; }

extern "C" unsigned int themepark_guest_memory_size() {
  return MEM_TotalPages() * 4096u;
}

extern "C" unsigned int themepark_guest_palette_rgb(unsigned int index) {
  if (index >= 256)
    return 0xFF000000u;
  const RGBEntry &colour = vga.dac.rgb[index];
  const unsigned int maximum = (1u << vga.dac.bits) - 1u;
  return 0xFF000000u | (colour.red * 255u / maximum << 16) |
         (colour.green * 255u / maximum << 8) |
         colour.blue * 255u / maximum;
}

extern "C" bool themepark_guest_main_is_running() {
  return RunningProgram && _stricmp(RunningProgram, "MAIN") == 0;
}

extern "C" bool themepark_guest_game_is_running() {
  if (!RunningProgram)
    return false;
  return _stricmp(RunningProgram, "MAIN") == 0 ||
         _stricmp(RunningProgram, "INTRO") == 0;
}

extern "C" bool themepark_guest_frame_is_renderable() {
  // DOS/4GW runs under INTRO.EXE or MAIN.EXE, so the process name alone is not
  // sufficient to hide its text banner.  Theme Park's actual pictures use a
  // VGA graphics mode; the private shell, DOSBox welcome page, and extender
  // banner all remain in text mode and must stay behind native loading art.
  return themepark_guest_game_is_running() && vga.mode != M_TEXT;
}

extern "C" bool themepark_guest_engine_state(unsigned int *width,
                                               unsigned int *height,
                                               unsigned int *framebuffer) {
  // Ghidra identifies these addresses in the retail DOS/4GW image. Before
  // trusting them, verify a distinctive prefix of the low-resolution setup
  // routine. This turns an executable revision mismatch into a clean fallback
  // instead of writing to an assumed address.
  static const Bit8u signature[] = {
      0x53, 0x56, 0x57, 0x55, 0x89, 0xE5, 0x81, 0xEC,
      0x38, 0x00, 0x00, 0x00, 0xC7, 0x45, 0xE4, 0x00,
      0x0F, 0x00, 0x00};
  if (!themepark_guest_main_is_running()) {
    gThemeParkImageLinearBase = kUnknownImageBase;
    gThemeParkSetupPhysical = kUnknownImageBase;
    return false;
  }
  if (gThemeParkImageLinearBase == kUnknownImageBase) {
    // Watcom uses flat selectors, so their cached base is zero even though the
    // LX image is relocated. Scan physical RAM for the unique setup routine,
    // then read its loader-adjusted absolute operand. That operand reveals the
    // virtual image base without assuming where DOS/4GW placed its pages.
    const Bitu memorySize = MEM_TotalPages() * 4096u;
    Bitu match = kUnknownImageBase;
    Bitu setupMatch = kUnknownImageBase;
    for (Bitu physical = 0;
         physical + 0x83u < memorySize; ++physical) {
      if (memcmp(MemBase + physical, signature, sizeof(signature)) != 0)
        continue;
      const Bit32u relocatedModeAddress = phys_readd(physical + 0x28u);
      if (relocatedModeAddress < 0x000DE5F4u)
        continue;
      const Bitu candidateBase = relocatedModeAddress - 0x000DE5F4u;
      const Bit32u candidateWidth = mem_readd(candidateBase + 0x000DE5B8u);
      const Bit32u candidateHeight = mem_readd(candidateBase + 0x000DE5C0u);
      if ((candidateWidth != 320 && candidateWidth != 427 &&
           candidateWidth != 640 && candidateWidth != 854) ||
          (candidateHeight != 200 && candidateHeight != 480))
        continue;
      // The extender may retain additional copies of the executable image.
      // Select the active, unmodified low-mode setup page by validating both
      // nearby immediate constants before remembering its physical address.
      if (candidateWidth == 320 &&
          (phys_readd(physical + 0x47u) != 320 ||
           phys_readd(physical + 0x7Fu) != 320))
        continue;
      if (match != kUnknownImageBase && match != candidateBase)
        return false; // A second match would make relocation ambiguous.
      match = candidateBase;
      setupMatch = physical;
    }
    if (match == kUnknownImageBase)
      return false;
    gThemeParkImageLinearBase = match;
    gThemeParkSetupPhysical = setupMatch;
  }

  const Bit32u engineWidth =
      mem_readd(gThemeParkImageLinearBase + 0x000DE5B8u);
  const Bit32u engineHeight =
      mem_readd(gThemeParkImageLinearBase + 0x000DE5C0u);
  const Bit32u engineFramebuffer =
      mem_readd(gThemeParkImageLinearBase + 0x000DE5BCu);
  if ((engineWidth != 320 && engineWidth != 427 && engineWidth != 640 &&
       engineWidth != 854) ||
      (engineHeight != 200 && engineHeight != 480) || !engineFramebuffer)
    return false;
  if (width)
    *width = engineWidth;
  if (height)
    *height = engineHeight;
  if (framebuffer)
    *framebuffer = engineFramebuffer;
  return true;
}

extern "C" bool themepark_guest_apply_widescreen() {
  unsigned int width = 0, height = 0, framebuffer = 0;
  if (!themepark_guest_engine_state(&width, &height, &framebuffer)) {
    gThemeParkWidescreenStatus = 1;
    return false;
  }
  if ((width == 320 || width == 427) && height == 200) {
    gThemeParkScreenState =
        mem_readb(gThemeParkImageLinearBase + 0x000D6652u);
    // Theme Park's fixed setup screens copy complete 320x200 bitmaps and draw
    // their controls with the original row stride. Keep those states native;
    // all other low-resolution states use the exact 427-pixel map viewport.
    const bool wantsWide = gThemeParkScreenState != 80u &&
                           gThemeParkScreenState != 102u;
    const unsigned int layoutError = themepark_set_low_layout(
        gThemeParkImageLinearBase, gThemeParkSetupPhysical,
        wantsWide ? 427u : 320u);
    if (layoutError != 0u) {
      gThemeParkWidescreenStatus = 0x100u + layoutError;
      return false;
    }
    gThemeParkWidescreenStatus = wantsWide ? 4u : 16u;
    return wantsWide;
  }
  if (height != 480 || (width != 640 && width != 854)) {
    gThemeParkWidescreenStatus = 2;
    return false;
  }
  gThemeParkWidescreenStatus = 2;
  return false; // High-resolution patching follows its separate audit.
}

extern "C" unsigned int themepark_guest_widescreen_status() {
  return gThemeParkWidescreenStatus;
}

extern "C" bool themepark_guest_copy_widescreen(unsigned int *destination,
                                                  unsigned int capacity,
                                                  unsigned int *width,
                                                  unsigned int *height) {
  unsigned int engineWidth = 0, engineHeight = 0, framebuffer = 0;
  if (!destination || !themepark_guest_engine_state(
                          &engineWidth, &engineHeight, &framebuffer) ||
      (engineWidth != 427 && engineWidth != 854))
    return false;
  const Bitu pixelCount = engineWidth * engineHeight;
  if (capacity < pixelCount)
    return false;
  static std::vector<Bit8u> indexed;
  indexed.resize(pixelCount);
  MEM_BlockRead(framebuffer, indexed.data(), pixelCount);

  for (Bitu index = 0; index != pixelCount; ++index)
    destination[index] = themepark_guest_palette_rgb(indexed[index]);
  if (width)
    *width = engineWidth;
  if (height)
    *height = engineHeight;
  return true;
}

extern "C" unsigned int themepark_guest_widescreen_diagnostics(
    unsigned int *legacyMatches, unsigned int *wideMatches) {
  if (legacyMatches)
    *legacyMatches = gThemeParkSetupPhysical;
  if (wideMatches)
    *wideMatches = gThemeParkImageLinearBase;
  return gThemeParkScreenState;
}

extern "C" void themepark_guest_selector_state(unsigned int *code,
                                                 unsigned int *data,
                                                 unsigned int *stack) {
  // Diagnostic-only values used to establish the DOS/4GW relocation on the
  // supported retail image. They are selector cache bases, not host pointers.
  if (code)
    *code = SegPhys(cs);
  if (data)
    *data = SegPhys(ds);
  if (stack)
    *stack = SegPhys(ss);
}
