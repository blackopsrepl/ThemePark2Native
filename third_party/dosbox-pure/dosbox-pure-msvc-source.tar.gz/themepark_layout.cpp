#include "themepark_layout.h"

#include "include/paging.h"

namespace {
// Each address is the first byte of a little-endian width operand identified
// in the supported retail MAIN.EXE. Some belong to setup or clipping code;
// keeping all of them synchronized also makes later mode changes predictable.
const Bitu kWidthOperands[] = {
    0x00066E3Du, 0x0007EC97u, 0x0007ECCFu, 0x0001165Fu,
    0x00011672u, 0x00011680u, 0x0007F5DCu, 0x0007F5EEu,
    0x00080E9Bu, 0x00081418u, 0x0008144Eu, 0x0008145Au,
};

bool isEitherWidth(Bit32u value) { return value == 320u || value == 427u; }

bool findLinearBias(Bitu setupPhysical, Bitu *bias) {
  static Bitu cachedSetup = ~(Bitu)0;
  static Bitu cachedBias = 0;
  if (setupPhysical == cachedSetup) {
    *bias = cachedBias;
    return true;
  }

  const Bitu physicalPage = setupPhysical & ~(Bitu)0xFFFu;
  const Bitu pageOffset = setupPhysical & 0xFFFu;
  Bitu match = ~(Bitu)0;
  for (Bitu page = 0; page < TLB_SIZE; ++page) {
    const Bitu linearPage = page << 12;
    if (PAGING_GetPhysicalPage(linearPage) != physicalPage)
      continue;
    const Bitu linearSetup = linearPage | pageOffset;
    if (linearSetup < 0x0007EC50u)
      continue;
    const Bitu candidate = linearSetup - 0x0007EC50u;
    if (!isEitherWidth(mem_readd_inline(candidate + kWidthOperands[0])))
      continue;
    if (match != ~(Bitu)0 && match != candidate)
      return false;
    match = candidate;
  }
  if (match == ~(Bitu)0)
    return false;
  cachedSetup = setupPhysical;
  cachedBias = match;
  *bias = match;
  return true;
}
} // namespace

unsigned int themepark_set_low_layout(Bitu imageBase, Bitu setupPhysical,
                                      unsigned int width) {
  if (!isEitherWidth(width))
    return 1u;
  if (setupPhysical < 0x0007EC50u)
    return 34u;
  // Invert DOSBox's live page map for the already-located setup instruction.
  // The resulting guest-linear bias remains valid even when DOS/4GW scatters
  // the executable's physical pages.
  Bitu linearBias = 0;
  if (!findLinearBias(setupPhysical, &linearBias))
    return 35u;

  // Validate every operand before changing any of them. An unsupported game
  // revision therefore falls back safely instead of receiving a partial patch.
  unsigned int operand = 0;
  for (Bitu address : kWidthOperands) {
    if (!isEitherWidth(mem_readd_inline(linearBias + address)))
      return 2u + operand;
    ++operand;
  }
  if (!isEitherWidth(mem_readd_inline(linearBias + 0x00080C25u)))
    return 32u;
  const Bit32u rewind = mem_readd_inline(linearBias + 0x00080F25u);
  if (rewind != 0xFFFFF884u && rewind != 0xFFFFF602u)
    return 33u;

  for (Bitu address : kWidthOperands)
    mem_writed_inline(linearBias + address, width);
  mem_writed_inline(linearBias + 0x00080C25u, width);
  mem_writed_inline(linearBias + 0x00080F25u,
                    width == 427u ? 0xFFFFF602u : 0xFFFFF884u);
  mem_writed(imageBase + 0x000DE5B8u, width);
  return 0u;
}
