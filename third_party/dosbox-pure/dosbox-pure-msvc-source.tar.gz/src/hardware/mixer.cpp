/*
 *  Copyright (C) 2002-2021  The DOSBox Team
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */


/*
	Remove the sdl code from here and have it handled in the sdlmain.
	That should call the mixer start from there or something.
*/

#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <math.h>

#ifdef C_DBP_NATIVE_MIDI
#if defined (WIN32)
//Midi listing
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <mmsystem.h>
#endif
#endif /* C_DBP_NATIVE_MIDI */

#ifdef C_DBP_USE_SDL
#include "SDL.h"
#endif
#include "mem.h"
#include "pic.h"
#include "dosbox.h"
#include "mixer.h"
#include "timer.h"
#include "setup.h"
#include "cross.h"
#include "support.h"
#include "mapper.h"
#include "hardware.h"
#include "programs.h"
#include "midi.h"

#define MIXER_SSIZE 4

//#define MIXER_SHIFT 14
//#define MIXER_REMAIN ((1<<MIXER_SHIFT)-1)

#define MIXER_VOLSHIFT 13

#define FREQ_SHIFT 14
#define FREQ_NEXT ( 1 << FREQ_SHIFT)
#define FREQ_MASK ( FREQ_NEXT -1 )

#define TICK_SHIFT 24
#define TICK_NEXT ( 1 << TICK_SHIFT)
#define TICK_MASK (TICK_NEXT -1)

#ifdef DBP_STANDALONE
#include "dbp_threads.h"
static Mutex DBP_AudioMutex;
#define SDL_LockAudio() DBP_AudioMutex.Lock();
#define SDL_UnlockAudio() DBP_AudioMutex.Unlock();
#define Callback_LockAudio() DBP_AudioMutex.Lock();
#define Callback_UnlockAudio() DBP_AudioMutex.Unlock();
#define SDL_PauseAudio(a)
#else
#ifndef C_DBP_USE_SDL
#define SDL_LockAudio()
#define SDL_UnlockAudio()
#define SDL_PauseAudio(a)
#endif
#define Callback_LockAudio()
#define Callback_UnlockAudio()
#endif

#ifdef C_DBP_LIBRETRO
bool dbp_swapstereo;
float dbp_volume_sb = 1, dbp_volume_midi = 1, dbp_volume_adlib = 1, dbp_volume_speaker = 1, dbp_volume_cdrom = 1, dbp_volume_other = 1;
#endif


static INLINE Bit16s MIXER_CLIP(Bits SAMP) {
	if (SAMP < MAX_AUDIO) {
		if (SAMP > MIN_AUDIO)
			return SAMP;
		else return MIN_AUDIO;
	} else return MAX_AUDIO;
}

static struct {
	Bit32s work[MIXER_BUFSIZE][2];
	//Write/Read pointers for the buffer
	Bitu pos,done;
	Bitu needed, min_needed, max_needed;
	//For every millisecond tick how many samples need to be generated
	Bit32u tick_add;
	Bit32u tick_counter;
	float mastervol[2];
	MixerChannel * channels;
	bool nosound;
	Bit32u freq;
	Bit32u blocksize;
} mixer;

Bit8u MixTemp[MIXER_BUFSIZE];

MixerChannel * MIXER_AddChannel(MIXER_Handler handler,Bitu freq,const char * name) {
	MixerChannel * chan=new MixerChannel();
	chan->scale = 1.0;
	chan->handler=handler;
	chan->name=name;
	chan->next=mixer.channels;
	chan->SetVolume(1,1);
	chan->enabled=false;
	chan->ever_enabled=false; //DBP: added for serialization
	chan->interpolate = false;
	chan->SetFreq(freq); //Sets interpolate as well.
	chan->last_samples_were_silence = true;
	chan->last_samples_were_stereo = false;
	chan->offset[0] = 0;
	chan->offset[1] = 0;
	mixer.channels = chan;
	return chan;
}

MixerChannel * MIXER_FindChannel(const char * name) {
	MixerChannel * chan=mixer.channels;
	while (chan) {
		if (!strcasecmp(chan->name,name)) break;
		chan=chan->next;
	}
	return chan;
}

void MIXER_DelChannel(MixerChannel* delchan) {
	MixerChannel * chan=mixer.channels;
	MixerChannel * * where=&mixer.channels;
	while (chan) {
		if (chan==delchan) {
			*where=chan->next;
			delete delchan;
			return;
		}
		where=&chan->next;
		chan=chan->next;
	}
}

void MixerChannel::UpdateVolume(void) {
#ifndef C_DBP_LIBRETRO
	volmul[0]=(Bits)((1 << MIXER_VOLSHIFT)*scale*volmain[0]*mixer.mastervol[0]);
	volmul[1]=(Bits)((1 << MIXER_VOLSHIFT)*scale*volmain[1]*mixer.mastervol[1]);
#else
	DBP_ASSERT(!strcmp(name, "SB") || !strcmp(name, "CMS") || !strcmp(name, "TSF") || !strcmp(name, "MT32") || !strcmp(name, "FM") || !strcmp(name, "SPKR") || !strcmp(name, "CDAUDIO") || !strcmp(name, "TANDY") || !strcmp(name, "TANDYDAC") || !strcmp(name, "GUS") || !strcmp(name, "DISNEY"));
	float vol = 1;
	switch ((name[0]<<8) | name[1])
	{
		case (('S'<<8) | 'B'): vol = dbp_volume_sb;      break; // "SB"
		case (('C'<<8) | 'M'): vol = dbp_volume_sb;      break; // "CMS"
		case (('T'<<8) | 'S'): vol = dbp_volume_midi;    break; // "TSF"
		case (('M'<<8) | 'T'): vol = dbp_volume_midi;    break; // "MT32"
		case (('F'<<8) | 'M'): vol = dbp_volume_adlib;   break; // "FM"
		case (('S'<<8) | 'P'): vol = dbp_volume_speaker; break; // "SPKR"
		case (('C'<<8) | 'D'): vol = dbp_volume_cdrom;   break; // "CDAUDIO"
		case (('T'<<8) | 'A'): vol = dbp_volume_other;   break; // "TANDY" / "TANDYDAC"
		case (('G'<<8) | 'U'): vol = dbp_volume_other;   break; // "GUS"
		case (('D'<<8) | 'I'): vol = dbp_volume_other;   break; // "DISNEY"
		default: DBP_ASSERT(0); break;
	}
	vol = (vol < 1.0f ? powf(10.0f,(vol-1.0f)*2.0f) : vol*vol);
	volmul[0]=(Bits)((1 << MIXER_VOLSHIFT)*scale*volmain[0]*mixer.mastervol[0]*vol);
	volmul[1]=(Bits)((1 << MIXER_VOLSHIFT)*scale*volmain[1]*mixer.mastervol[1]*vol);
#endif
}

void MixerChannel::SetVolume(float _left,float _right) {
	volmain[0]=_left;
	volmain[1]=_right;
	UpdateVolume();
}

void MixerChannel::SetScale( float f ) {
	scale = f;
	UpdateVolume();
}

void MixerChannel::Enable(bool _yesno) {
	if (_yesno==enabled) return;
	enabled=_yesno;
	if (enabled) {
		ever_enabled = true; //DBP: added for serialization
		freq_counter = 0;
		SDL_LockAudio();
		if (done<mixer.done) done=mixer.done;
		SDL_UnlockAudio();
	}
}

void MixerChannel::SetFreq(Bitu freq) {
	freq_add=(freq<<FREQ_SHIFT)/mixer.freq;

	if (freq != mixer.freq) {
		interpolate = true;
	} else {
		interpolate = false;
	}
}

void MixerChannel::Mix(Bitu _needed) {
	needed=_needed;
	while (enabled && needed>done) {
		Bitu left = (needed - done);
		left *= freq_add;
		left  = (left >> FREQ_SHIFT) + ((left & FREQ_MASK)!=0);
		// DBP: Added to avoid potential overflow of MixTemp
		if (left > (MIXER_BUFSIZE/4)) left = (MIXER_BUFSIZE/4);
		handler(left);
	}
}

void MixerChannel::AddSilence(void) {
	if (done < needed) {
		if(prevSample[0] == 0 && prevSample[1] == 0) {
			done = needed;
			//Make sure the next samples are zero when they get switched to prev
			nextSample[0] = 0;
			nextSample[1] = 0;
			//This should trigger an instant request for new samples
			freq_counter = FREQ_NEXT;
		} else {
			bool stereo = last_samples_were_stereo;
			//Position where to write the data
			Bitu mixpos = mixer.pos + done;
			while (done < needed) {
				// Maybe depend on sample rate. (the 4)
				if (prevSample[0] > 4)       nextSample[0] = prevSample[0] - 4;
				else if (prevSample[0] < -4) nextSample[0] = prevSample[0] + 4;
				else nextSample[0] = 0;
				if (prevSample[1] > 4)       nextSample[1] = prevSample[1] - 4;
				else if (prevSample[1] < -4) nextSample[1] = prevSample[1] + 4;
				else nextSample[1] = 0;

				mixpos &= MIXER_BUFMASK;
				Bit32s* write = mixer.work[mixpos];

				write[0] += prevSample[0] * volmul[0];
				write[1] += (stereo ? prevSample[1] : prevSample[0]) * volmul[1];

				prevSample[0] = nextSample[0];
				prevSample[1] = nextSample[1];
				mixpos++;
				done++;
				freq_counter = FREQ_NEXT;
			} 
		}
	}
	last_samples_were_silence = true;
	offset[0] = offset[1] = 0;
}

//4 seems to work . Disabled for now
#define MIXER_UPRAMP_STEPS 0
#define MIXER_UPRAMP_SAVE 512

template<class Type,bool stereo,bool signeddata,bool nativeorder>
inline void MixerChannel::AddSamples(Bitu len, const Type* data) {
	last_samples_were_stereo = stereo;

	//Position where to write the data
	Bitu mixpos = mixer.pos + done;
	//Position in the incoming data
	Bitu pos = 0;
	//Mix and data for the full length
	while (1) {
		//Does new data need to get read?
		while (freq_counter >= FREQ_NEXT) {
			//Would this overflow the source data, then it's time to leave
			if (pos >= len) {
				last_samples_were_silence = false;
#if MIXER_UPRAMP_STEPS > 0
				if (offset[0] || offset[1]) {
					//Should be safe to do, as the value inside offset is 16 bit while offset itself is at least 32 bit
					offset[0] = (offset[0]*(MIXER_UPRAMP_STEPS-1))/MIXER_UPRAMP_STEPS;
					offset[1] = (offset[1]*(MIXER_UPRAMP_STEPS-1))/MIXER_UPRAMP_STEPS;
					if (offset[0] < MIXER_UPRAMP_SAVE && offset[0] > -MIXER_UPRAMP_SAVE) offset[0] = 0;
					if (offset[1] < MIXER_UPRAMP_SAVE && offset[1] > -MIXER_UPRAMP_SAVE) offset[1] = 0;
				}
#endif
				return;
			}
			freq_counter -= FREQ_NEXT;
			prevSample[0] = nextSample[0];
			if (stereo) {
				prevSample[1] = nextSample[1];
			}
			if ( sizeof( Type) == 1) {
				if (!signeddata) {
					if (stereo) {
						nextSample[0]=(((Bit8s)(data[pos*2+0] ^ 0x80)) << 8);
						nextSample[1]=(((Bit8s)(data[pos*2+1] ^ 0x80)) << 8);
					} else {
						nextSample[0]=(((Bit8s)(data[pos] ^ 0x80)) << 8);
					}
				} else {
					if (stereo) {
						nextSample[0]=(data[pos*2+0] << 8);
						nextSample[1]=(data[pos*2+1] << 8);
					} else {
						nextSample[0]=(data[pos] << 8);
					}
				}
			//16bit and 32bit both contain 16bit data internally
			} else  {
				if (signeddata) {
					if (stereo) {
						if (nativeorder) {
							nextSample[0]=data[pos*2+0];
							nextSample[1]=data[pos*2+1];
						} else {
							if ( sizeof( Type) == 2) {
								nextSample[0]=(Bit16s)host_readw((HostPt)&data[pos*2+0]);
								nextSample[1]=(Bit16s)host_readw((HostPt)&data[pos*2+1]);
							} else {
								nextSample[0]=(Bit32s)host_readd((HostPt)&data[pos*2+0]);
								nextSample[1]=(Bit32s)host_readd((HostPt)&data[pos*2+1]);
							}
						}
					} else {
						if (nativeorder) {
							nextSample[0] = data[pos];
						} else {
							if ( sizeof( Type) == 2) {
								nextSample[0]=(Bit16s)host_readw((HostPt)&data[pos]);
							} else {
								nextSample[0]=(Bit32s)host_readd((HostPt)&data[pos]);
							}
						}
					}
				} else {
					if (stereo) {
						if (nativeorder) {
							nextSample[0]=(Bits)data[pos*2+0]-32768;
							nextSample[1]=(Bits)data[pos*2+1]-32768;
						} else {
							if ( sizeof( Type) == 2) {
								nextSample[0]=(Bits)host_readw((HostPt)&data[pos*2+0])-32768;
								nextSample[1]=(Bits)host_readw((HostPt)&data[pos*2+1])-32768;
							} else {
								nextSample[0]=(Bits)host_readd((HostPt)&data[pos*2+0])-32768;
								nextSample[1]=(Bits)host_readd((HostPt)&data[pos*2+1])-32768;
							}
						}
					} else {
						if (nativeorder) {
							nextSample[0]=(Bits)data[pos]-32768;
						} else {
							if ( sizeof( Type) == 2) {
								nextSample[0]=(Bits)host_readw((HostPt)&data[pos])-32768;
							} else {
								nextSample[0]=(Bits)host_readd((HostPt)&data[pos])-32768;
							}
						}
					}
				}
			}
			//This sample has been handled now, increase position
			pos++;
#if MIXER_UPRAMP_STEPS > 0
			if (last_samples_were_silence && pos == 1) {
				offset[0] = nextSample[0] - prevSample[0];
				if (stereo) offset[1] = nextSample[1] - prevSample[1];
				//Don't bother with small steps.
				if (offset[0] < (MIXER_UPRAMP_SAVE*4) && offset[0] > (-MIXER_UPRAMP_SAVE*4)) offset[0] = 0;
				if (offset[1] < (MIXER_UPRAMP_SAVE*4) && offset[1] > (-MIXER_UPRAMP_SAVE*4)) offset[1] = 0;
			}

			if (offset[0] || offset[1]) {
				nextSample[0] = nextSample[0] - (offset[0]*(MIXER_UPRAMP_STEPS*static_cast<Bits>(len)-static_cast<Bits>(pos))) /( MIXER_UPRAMP_STEPS*static_cast<Bits>(len) );
				nextSample[1] = nextSample[1] - (offset[1]*(MIXER_UPRAMP_STEPS*static_cast<Bits>(len)-static_cast<Bits>(pos))) /( MIXER_UPRAMP_STEPS*static_cast<Bits>(len) );
			}
#endif
		}
		//Where to write
		mixpos &= MIXER_BUFMASK;
		Bit32s* write = mixer.work[mixpos];
		if (!interpolate) {
			write[0] += prevSample[0] * volmul[0];
			write[1] += (stereo ? prevSample[1] : prevSample[0]) * volmul[1];
		}
		else {
			Bits diff_mul = freq_counter & FREQ_MASK;
			Bits sample = prevSample[0] + (((nextSample[0] - prevSample[0]) * diff_mul) >> FREQ_SHIFT);
			write[0] += sample*volmul[0];
			if (stereo) {
				sample = prevSample[1] + (((nextSample[1] - prevSample[1]) * diff_mul) >> FREQ_SHIFT);
			}
			write[1] += sample*volmul[1];
		}
		//Prepare for next sample
		freq_counter += freq_add;
		mixpos++;
		done++;
	}
}

void MixerChannel::AddStretched(Bitu len,Bit16s * data) {
	if (done >= needed) {
		LOG_MSG("Can't add, buffer full");
		return;
	}
	//Target samples this inputs gets stretched into
	Bitu outlen = needed - done;
	Bitu index = 0;
	Bitu index_add = (len << FREQ_SHIFT)/outlen;
	Bitu mixpos = mixer.pos + done;
	done = needed;
	Bitu pos = 0;

	while (outlen--) {
		Bitu new_pos = index >> FREQ_SHIFT;
		if (pos != new_pos) {
			pos = new_pos;
			//Forward the previous sample
			prevSample[0] = data[0];
			data++;
		}
		Bits diff = data[0] - prevSample[0];
		Bits diff_mul = index & FREQ_MASK;
		index += index_add;
		mixpos &= MIXER_BUFMASK;
		Bits sample = prevSample[0] + ((diff * diff_mul) >> FREQ_SHIFT);
		mixer.work[mixpos][0] += sample * volmul[0];
		mixer.work[mixpos][1] += sample * volmul[1];
		mixpos++;
	}
}

void MixerChannel::AddSamples_m8(Bitu len, const Bit8u * data) {
	AddSamples<Bit8u,false,false,true>(len,data);
}
void MixerChannel::AddSamples_s8(Bitu len,const Bit8u * data) {
	AddSamples<Bit8u,true,false,true>(len,data);
}
void MixerChannel::AddSamples_m8s(Bitu len,const Bit8s * data) {
	AddSamples<Bit8s,false,true,true>(len,data);
}
void MixerChannel::AddSamples_s8s(Bitu len,const Bit8s * data) {
	AddSamples<Bit8s,true,true,true>(len,data);
}
void MixerChannel::AddSamples_m16(Bitu len,const Bit16s * data) {
	AddSamples<Bit16s,false,true,true>(len,data);
}
void MixerChannel::AddSamples_s16(Bitu len,const Bit16s * data) {
	AddSamples<Bit16s,true,true,true>(len,data);
}
void MixerChannel::AddSamples_m16u(Bitu len,const Bit16u * data) {
	AddSamples<Bit16u,false,false,true>(len,data);
}
void MixerChannel::AddSamples_s16u(Bitu len,const Bit16u * data) {
	AddSamples<Bit16u,true,false,true>(len,data);
}
void MixerChannel::AddSamples_m32(Bitu len,const Bit32s * data) {
	AddSamples<Bit32s,false,true,true>(len,data);
}
void MixerChannel::AddSamples_s32(Bitu len,const Bit32s * data) {
	AddSamples<Bit32s,true,true,true>(len,data);
}
void MixerChannel::AddSamples_m16_nonnative(Bitu len,const Bit16s * data) {
	AddSamples<Bit16s,false,true,false>(len,data);
}
void MixerChannel::AddSamples_s16_nonnative(Bitu len,const Bit16s * data) {
	AddSamples<Bit16s,true,true,false>(len,data);
}
void MixerChannel::AddSamples_m16u_nonnative(Bitu len,const Bit16u * data) {
	AddSamples<Bit16u,false,false,false>(len,data);
}
void MixerChannel::AddSamples_s16u_nonnative(Bitu len,const Bit16u * data) {
	AddSamples<Bit16u,true,false,false>(len,data);
}
void MixerChannel::AddSamples_m32_nonnative(Bitu len,const Bit32s * data) {
	AddSamples<Bit32s,false,true,false>(len,data);
}
void MixerChannel::AddSamples_s32_nonnative(Bitu len,const Bit32s * data) {
	AddSamples<Bit32s,true,true,false>(len,data);
}

void MixerChannel::FillUp(void) {
	if (!enabled) return;

	SDL_LockAudio();
	if (done < mixer.done) {
		SDL_UnlockAudio();
		return;
	}
	float index = PIC_TickIndex();
	Mix((Bitu)(index * mixer.needed));
	SDL_UnlockAudio();
}

extern bool ticksLocked;
static inline bool Mixer_irq_important(void) {
#ifdef C_DBP_ENABLE_CAPTURE
	/* In some states correct timing of the irqs is more important than
	 * non stuttering audio */
	return (ticksLocked || (CaptureState & (CAPTURE_WAVE|CAPTURE_VIDEO)));
#elif defined(C_DBP_CUSTOMTIMING)
	return false;
#else
	return ticksLocked;
#endif
}

static Bit32u calc_tickadd(Bit32u freq) {
#if TICK_SHIFT > 16
	Bit64u freq64 = static_cast<Bit64u>(freq);
	freq64 = (freq64<<TICK_SHIFT)/1000;
	Bit32u r = static_cast<Bit32u>(freq64);
	return r;
#else
	return (freq<<TICK_SHIFT)/1000;
#endif
}

/* Mix a certain amount of new samples */
static void MIXER_MixData(Bitu needed) {
	MixerChannel * chan=mixer.channels;
	while (chan) {
		chan->Mix(needed);
		chan=chan->next;
	}
#ifdef C_DBP_ENABLE_CAPTURE
	if (CaptureState & (CAPTURE_WAVE|CAPTURE_VIDEO)) {
		Bit16s convert[1024][2];
		Bitu added=needed-mixer.done;
		if (added>1024)
			added=1024;
		Bitu readpos=(mixer.pos+mixer.done)&MIXER_BUFMASK;
		for (Bitu i=0;i<added;i++) {
			Bits sample=mixer.work[readpos][0] >> MIXER_VOLSHIFT;
			convert[i][0]=MIXER_CLIP(sample);
			sample=mixer.work[readpos][1] >> MIXER_VOLSHIFT;
			convert[i][1]=MIXER_CLIP(sample);
			readpos=(readpos+1)&MIXER_BUFMASK;
		}
		CAPTURE_AddWave( mixer.freq, added, (Bit16s*)convert );
	}
#endif
	//Reset the the tick_add for constant speed
	if( Mixer_irq_important() )
		mixer.tick_add = calc_tickadd(mixer.freq);
	mixer.done = needed;
}

static void MIXER_Mix(void) {
	SDL_LockAudio();
	MIXER_MixData(mixer.needed);
	mixer.tick_counter += mixer.tick_add;
	mixer.needed+=(mixer.tick_counter >> TICK_SHIFT);
	mixer.tick_counter &= TICK_MASK;
	SDL_UnlockAudio();
}

static void MIXER_Mix_NoSound(void) {
	MIXER_MixData(mixer.needed);
	/* Clear piece we've just generated */
	for (Bitu i=0;i<mixer.needed;i++) {
		mixer.work[mixer.pos][0]=0;
		mixer.work[mixer.pos][1]=0;
		mixer.pos=(mixer.pos+1)&MIXER_BUFMASK;
	}
	/* Reduce count in channels */
	for (MixerChannel * chan=mixer.channels;chan;chan=chan->next) {
		if (chan->done>mixer.needed) chan->done-=mixer.needed;
		else chan->done=0;
	}
	/* Set values for next tick */
	mixer.tick_counter += mixer.tick_add;
	mixer.needed = (mixer.tick_counter >> TICK_SHIFT);
	mixer.tick_counter &= TICK_MASK;
	mixer.done=0;
}


#define INDEX_SHIFT_LOCAL 14

#ifdef C_DBP_USE_SDL
static void SDLCALL
#else
void
#endif
MIXER_CallBack(void * /*userdata*/, uint8_t *stream, int len) {
	Bitu need=(Bitu)len/MIXER_SSIZE;
	Bit16s * output=(Bit16s *)stream;
	Bitu reduce;
	Bitu pos;
	//Local resampling counter to manipulate the data when sending it off to the callback
	Bitu index_add = (1<<INDEX_SHIFT_LOCAL);
	Bitu index = (index_add%need)?need:0;

	Bits sample;
	/* Enough room in the buffer ? */
	Callback_LockAudio();
	if (mixer.done < need) {
//		LOG_MSG("Full underrun need %d, have %d, min %d", need, mixer.done, mixer.min_needed);
		if((need - mixer.done) > (need >>7) ) //Max 1 percent stretch.
			{ Callback_UnlockAudio(); return; }
		reduce = mixer.done;
		index_add = (reduce << INDEX_SHIFT_LOCAL) / need;
		mixer.tick_add = calc_tickadd(mixer.freq+mixer.min_needed);
	} else if (mixer.done < mixer.max_needed) {
		Bitu left = mixer.done - need;
		if (left < mixer.min_needed) {
			if( !Mixer_irq_important() ) {
				Bitu needed = mixer.needed - need;
				Bitu diff = (mixer.min_needed>needed?mixer.min_needed:needed) - left;
				mixer.tick_add = calc_tickadd(mixer.freq+(diff*3));
				left = 0; //No stretching as we compensate with the tick_add value
			} else {
				left = (mixer.min_needed - left);
				left = 1 + (2*left) / mixer.min_needed; //left=1,2,3
			}
//			LOG_MSG("needed underrun need %d, have %d, min %d, left %d", need, mixer.done, mixer.min_needed, left);
			reduce = need - left;
			index_add = (reduce << INDEX_SHIFT_LOCAL) / need;
		} else {
			reduce = need;
			index_add = (1 << INDEX_SHIFT_LOCAL);
//			LOG_MSG("regular run need %d, have %d, min %d, left %d", need, mixer.done, mixer.min_needed, left);

			/* Mixer tick value being updated:
			 * 3 cases:
			 * 1) A lot too high. >division by 5. but maxed by 2* min to prevent too fast drops.
			 * 2) A little too high > division by 8
			 * 3) A little to nothing above the min_needed buffer > go to default value
			 */
			Bitu diff = left - mixer.min_needed;
			if(diff > (mixer.min_needed<<1)) diff = mixer.min_needed<<1;
			if(diff > (mixer.min_needed>>1))
				mixer.tick_add = calc_tickadd(mixer.freq-(diff/5));
			else if (diff > (mixer.min_needed>>2))
				mixer.tick_add = calc_tickadd(mixer.freq-(diff>>3));
			else
				mixer.tick_add = calc_tickadd(mixer.freq);
		}
	} else {
		/* There is way too much data in the buffer */
//		LOG_MSG("overflow run need %d, have %d, min %d", need, mixer.done, mixer.min_needed);
		if (mixer.done > MIXER_BUFSIZE)
			index_add = MIXER_BUFSIZE - 2*mixer.min_needed;
		else
			index_add = mixer.done - 2*mixer.min_needed;
		index_add = (index_add << INDEX_SHIFT_LOCAL) / need;
		reduce = mixer.done - 2* mixer.min_needed;
		mixer.tick_add = calc_tickadd(mixer.freq-(mixer.min_needed/5));
	}
	/* Reduce done count in all channels */
	for (MixerChannel * chan=mixer.channels;chan;chan=chan->next) {
		if (chan->done>reduce) chan->done-=reduce;
		else chan->done=0;
	}

	// Reset mixer.tick_add when irqs are important
	if( Mixer_irq_important() )
		mixer.tick_add = calc_tickadd(mixer.freq);

	mixer.done -= reduce;
	mixer.needed -= reduce;
	pos = mixer.pos;
	mixer.pos = (mixer.pos + reduce) & MIXER_BUFMASK;
	if(need != reduce) {
		while (need--) {
			Bitu i = (pos + (index >> INDEX_SHIFT_LOCAL )) & MIXER_BUFMASK;
			index += index_add;
			sample=mixer.work[i][0]>>MIXER_VOLSHIFT;
			*output++=MIXER_CLIP(sample);
			sample=mixer.work[i][1]>>MIXER_VOLSHIFT;
			*output++=MIXER_CLIP(sample);
		}
		/* Clean the used buffer */
		while (reduce--) {
			pos &= MIXER_BUFMASK;
			mixer.work[pos][0]=0;
			mixer.work[pos][1]=0;
			pos++;
		}
	} else {
		while (reduce--) {
			pos &= MIXER_BUFMASK;
			sample=mixer.work[pos][0]>>MIXER_VOLSHIFT;
			*output++=MIXER_CLIP(sample);
			sample=mixer.work[pos][1]>>MIXER_VOLSHIFT;
			*output++=MIXER_CLIP(sample);
			mixer.work[pos][0]=0;
			mixer.work[pos][1]=0;
			pos++;
		}
	}
	Callback_UnlockAudio();

#ifdef C_DBP_LIBRETRO
	if (dbp_swapstereo)
	{
		for (Bit16s *p = (Bit16s *)stream, *pEnd = p + (size_t)len/2; p != pEnd; p += 2) std::swap(p[0], p[1]);
	}
#endif
}

#undef INDEX_SHIFT_LOCAL

static void MIXER_Stop(Section* /*sec*/) {
}

class MIXER : public Program {
public:
	void MakeVolume(char * scan,float & vol0,float & vol1) {
		Bitu w=0;
		bool db=(toupper(*scan)=='D');
		if (db) scan++;
		while (*scan) {
			if (*scan==':') {
				++scan;w=1;
			}
			char * before=scan;
			float val=(float)strtod(scan,&scan);
			if (before==scan) {
				++scan;continue;
			}
			if (!db) val/=100;
			else val=powf(10.0f,(float)val/20.0f);
			if (val<0) val=1.0f;
			if (!w) {
				vol0=val;
			} else {
				vol1=val;
			}
		}
		if (!w) vol1=vol0;
	}

	void Run(void) {
		if(cmd->FindExist("/LISTMIDI")) {
			ListMidi();
			return;
		}
		if (cmd->FindString("MASTER",temp_line,false)) {
			MakeVolume((char *)temp_line.c_str(),mixer.mastervol[0],mixer.mastervol[1]);
		}
		MixerChannel * chan = mixer.channels;
		while (chan) {
			if (cmd->FindString(chan->name,temp_line,false)) {
				MakeVolume((char *)temp_line.c_str(),chan->volmain[0],chan->volmain[1]);
			}
			chan->UpdateVolume();
			chan = chan->next;
		}
		if (cmd->FindExist("/NOSHOW")) return;
		WriteOut("Channel  Main    Main(dB)\n");
		ShowVolume("MASTER",mixer.mastervol[0],mixer.mastervol[1]);
		for (chan = mixer.channels;chan;chan = chan->next)
			ShowVolume(chan->name,chan->volmain[0],chan->volmain[1]);
	}
private:
	void ShowVolume(const char * name,float vol0,float vol1) {
		WriteOut("%-8s %3.0f:%-3.0f  %+3.2f:%-+3.2f \n",name,
			vol0*100,vol1*100,
			20*log(vol0)/log(10.0f),20*log(vol1)/log(10.0f)
		);
	}

	void ListMidi(){
		if(midi.handler) midi.handler->ListAll(this);
	};

};

static void MIXER_ProgramStart(Program * * make) {
	*make=new MIXER;
}

MixerChannel* MixerObject::Install(MIXER_Handler handler,Bitu freq,const char * name){
	if(!installed) {
		if(strlen(name) > 31) E_Exit("Too long mixer channel name");
		safe_strncpy(m_name,name,32);
		installed = true;
		return MIXER_AddChannel(handler,freq,name);
	} else {
		E_Exit("already added mixer channel.");
		return 0; //Compiler happy
	}
}

MixerObject::~MixerObject(){
	if(!installed) return;
	MIXER_DelChannel(MIXER_FindChannel(m_name));
}


void MIXER_Init(Section* sec) {
	sec->AddDestroyFunction(&MIXER_Stop);

	Section_prop * section=static_cast<Section_prop *>(sec);
	/* Read out config section */
	mixer.freq=section->Get_int("rate");
	mixer.nosound=section->Get_bool("nosound");
	mixer.blocksize=section->Get_int("blocksize");

	/* Initialize the internal stuff */
	mixer.channels=0;
	mixer.pos=0;
	mixer.done=0;
	memset(mixer.work,0,sizeof(mixer.work));
	mixer.mastervol[0]=1.0f;
	mixer.mastervol[1]=1.0f;

#ifdef C_DBP_USE_SDL
	/* Start the Mixer using SDL Sound at 22 khz */
	SDL_AudioSpec spec;
	SDL_AudioSpec obtained;

	spec.freq=mixer.freq;
	spec.format=AUDIO_S16SYS;
	spec.channels=2;
	spec.callback=MIXER_CallBack;
	spec.userdata=NULL;
	spec.samples=(Uint16)mixer.blocksize;
#endif

	mixer.tick_counter=0;
	if (mixer.nosound) {
		LOG_MSG("MIXER: No Sound Mode Selected.");
		mixer.tick_add=calc_tickadd(mixer.freq);
		TIMER_AddTickHandler(MIXER_Mix_NoSound);
#ifdef C_DBP_USE_SDL
	} else if (SDL_OpenAudio(&spec, &obtained) <0 ) {
		mixer.nosound = true;
		LOG_MSG("MIXER: Can't open audio: %s , running in nosound mode.",SDL_GetError());
		mixer.tick_add=calc_tickadd(mixer.freq);
		TIMER_AddTickHandler(MIXER_Mix_NoSound);
#endif
	} else {
#ifdef C_DBP_USE_SDL
		if ((mixer.freq != static_cast<Bit32u>(obtained.freq)) || (mixer.blocksize != obtained.samples))
			LOG_MSG("MIXER: Got different values from SDL: freq %d, blocksize %d",obtained.freq,obtained.samples);
		mixer.freq=obtained.freq;
		mixer.blocksize=obtained.samples;
#endif
		mixer.tick_add=calc_tickadd(mixer.freq);
		TIMER_AddTickHandler(MIXER_Mix);
		SDL_PauseAudio(0);
	}
	//1000 = 8 *125
	mixer.tick_counter = (mixer.freq%125)?TICK_NEXT:0;

	mixer.min_needed = section->Get_int("prebuffer");
	if (mixer.min_needed > 100) mixer.min_needed = 100;
	mixer.min_needed = (mixer.freq*mixer.min_needed)/1000;
	mixer.max_needed = mixer.blocksize * 2 + 2*mixer.min_needed;
	mixer.needed = mixer.min_needed+1;
	PROGRAMS_MakeFile("MIXER.COM",MIXER_ProgramStart);
}

Bit32u DBP_MIXER_GetFrequency()
{
	return mixer.freq;
}

Bit32u DBP_MIXER_DoneSamplesCount()
{
	return mixer.done;
}

void DBP_MIXER_ScrapAudio()
{
	// Scrap all but 100 samples
	Bit8u dummy[64 * MIXER_SSIZE];
	while (mixer.done > 100)
		MIXER_CallBack(0, dummy, (mixer.done > 164 ? 64 : mixer.done - 100) * MIXER_SSIZE);
}

void DBP_MIXER_ApplyVolumes()
{
	for (MixerChannel* chan = mixer.channels; chan; chan = chan->next) chan->UpdateVolume();
}

void DBP_MIXER_MutexLock(bool flag)
{
	if (flag) { SDL_LockAudio(); } else { SDL_UnlockAudio(); }
}

#include <dbp_serialize.h>

DBPArchiveOptional::DBPArchiveOptional(DBPArchive& ar_outer, MixerChannel* chan) : DBPArchiveOptional(ar_outer, chan, (chan && chan->ever_enabled))
{
	if (IsSkip()) return;
	DBP_ASSERT(mode != DBPArchive::MODE_ZERO); // when restarting (zeroing) all channels should have been set to NULL

	MixerChannel dummy;
	if (!chan) chan = &dummy;
	Bit32u freq_add = (Bit32u)chan->freq_add;
	Serialize(chan->enabled).Serialize(freq_add);

	// OPTIONAL_RESET expects us to reset things to an initial state which we can't do for volume (and freq), so just leave as is
	MixerChannel* overwrite_volume = (optionality == OPTIONAL_RESET ? &dummy : chan);
	SerializeArray(overwrite_volume->volmain).Serialize(overwrite_volume->scale);

	if (mode != DBPArchive::MODE_LOAD) return;
	if (optionality == OPTIONAL_SERIALIZE)
	{
		if (freq_add && freq_add != chan->freq_add)
		{
			Bitu freq = (freq_add*mixer.freq)>>FREQ_SHIFT;
			Bitu freq_diff = (mixer.freq > freq ? mixer.freq - freq : freq - mixer.freq);
			chan->interpolate = (freq_diff > 10);
			chan->freq_add = freq_add;
		}
		chan->ever_enabled = true;
		chan->UpdateVolume();
	}
	if (optionality == OPTIONAL_RESET)
	{
		chan->ever_enabled = false;
	}
	if (optionality != OPTIONAL_DISCARD)
	{
		chan->done = chan->needed = 0;
		mixer.pos = 0;
		mixer.done = 0;
		mixer.needed = mixer.min_needed+1;
	}
}

#ifdef DBP_STANDALONE
static SpinLock EmuMixerLock;
static volatile bool emulation_sleeping;

void DBPS_MIXER_AroundEmulationWait(bool start_wait)
{
	EmuMixerLock.Lock();
	emulation_sleeping = start_wait;
	EmuMixerLock.Unlock();
}

float DBPS_AudioMix(short* buffer, Bit32u samples, float speed, int max_wait)
{
	//static Bitu mixer_debug_output, mixer_debug_generated;
	const Bitu want = (speed == 1.0f ? (Bitu)samples : (speed > 999999.0f ? (Bitu)mixer.done : (Bitu)(samples * speed)));
	if (want > mixer.done)
	{
		extern Bit64s dbp_cpu_features_get_time_usec(void);
		const Bit64s usec = dbp_cpu_features_get_time_usec(), ms = (Bit64s)max_wait, midusec = usec+ms*500, maxusec = usec+ms*2000, limitusec = usec+ms*1000;

		// First wait a bit for the emulation to naturally generate audio (unless running in aggressive mode)
		static Bit8u aggressive;
		while (!aggressive && want > mixer.done)
		{
			retro_sleep(0);
			if ((dbp_cpu_features_get_time_usec()) > midusec) break;
		}
		if (aggressive) aggressive--;

		// Then if not yet enough audio data exists, increase mixer.needed to the amount we want to output and try have it force generated
		Callback_LockAudio();
		const Bitu forcegen = (want > mixer.needed ? (want - mixer.needed) : 0), newneeded = mixer.needed + forcegen; //, olddone = mixer.done;
		mixer.needed = newneeded;
		Callback_UnlockAudio();
		while (want > mixer.done)
		{
			EmuMixerLock.Lock();
			if (emulation_sleeping) { MIXER_Mix(); EmuMixerLock.Unlock(); continue; } // force mix while emulation sleeps
			EmuMixerLock.Unlock();
			retro_sleep(0);
			if ((dbp_cpu_features_get_time_usec()) > maxusec) break; // emulation lagging (or crashed)
		}
		//if (mixer.done < want) printf("[DBMIXER] Failed to force generate %u samples (only got %u)\n", (unsigned)forcegen, (unsigned)(mixer.done - olddone));
		//mixer_debug_generated += (mixer.done - olddone);

		// If mixer.needed increased since before, it was naturally done by the emulation so we can try to subtract some of our forced amount again
		if (forcegen && mixer.needed > newneeded)
		{
			Callback_LockAudio();
			const Bitu natural_increase = (mixer.needed - newneeded), reduce_generated = (natural_increase > forcegen ? forcegen : natural_increase);
			mixer.needed -= reduce_generated;
			if (mixer.needed < mixer.done) mixer.needed = mixer.done; // needed can't go lower than done
			Callback_UnlockAudio();
			//mixer_debug_generated -= reduce_generated;
		}

		// We allow audio generation to wait a bit longer than the audio latency because some audio drivers can deal with it for 1 frame (but if it happens once we enable aggressive mode)
		if (dbp_cpu_features_get_time_usec() > limitusec)
		{
			aggressive = 5;
			//printf("[DBMIXER] Took %u musec (beyond allowed %u)\n", (unsigned)(dbp_cpu_features_get_time_usec() - usec), (unsigned)((Bit64s)maxwait * 1000));
		}
	}

	Bitu have = mixer.done, use;
	if (have == 0 || want == 0)
	{
		memset(buffer, 0, samples * 4);
		return 1.0f;
	}

	double audio_stretch = 1.0;
	if (want == samples && have >= want)
	{
		use = want;
		MIXER_CallBack(NULL, (unsigned char*)buffer,  (int)(want * 4));
	}
	else
	{
		enum { UI_MAX_SAMPLES = 4096*4 };
		static short stretchbuf[UI_MAX_SAMPLES * 2]; // stereo

		if (speed == 0.0f) use = (have < samples ? have : (Bitu)samples);
		else               use = (have < want    ? have : want);

		if (use > UI_MAX_SAMPLES) use = UI_MAX_SAMPLES;
		audio_stretch = ((speed == 0.0f) ? 1.0 : (double)use / samples); // don't stretch during frame stepping (speed 0)
		MIXER_CallBack(NULL, (unsigned char*)stretchbuf, (int)(use* 4));
		//printf("[DBMIXER] Stretch %d (of %d available total) into %d (factor %f)\n", (int)use, (int)have, (int)samples, (float)audio_stretch);

		if (0)
		{
			for (Bitu i = 0; i != samples*2; i++, buffer++) // repeat samples
			{
				buffer[0] = stretchbuf[i < (use*2) ? i : (use*2) - (i % (use*2))];
			}
		}
		else
		{
			for (Bitu i = 0, jMax = use - 1; i != samples; i++, buffer += 2) // linear interpolation
			{
				const double src_pos_float = i * audio_stretch;
				const Bitu j0 = (Bitu)src_pos_float, j1 = j0 + (Bitu)(j0 != jMax);
				const double frac = src_pos_float - j0;
				buffer[0] = (short)((1.0 - frac) * stretchbuf[j0 * 2 + 0] + frac * stretchbuf[j1 * 2 + 0]); // stretchbuf[j0 * 2 + 0] // simple nearest
				buffer[1] = (short)((1.0 - frac) * stretchbuf[j0 * 2 + 1] + frac * stretchbuf[j1 * 2 + 1]); // stretchbuf[j0 * 2 + 1] // simple nearest
			}
		}

		if (speed == 0.0f && use < samples) { memset(buffer - (samples - use) * 2, 0, (samples - use) * 4); }
	}

	// The mixer.tick_add should always be at the default value after running MIXER_CallBack (due to Mixer_irq_important always returning false)
	DBP_ASSERT(mixer.tick_add == calc_tickadd(mixer.freq));
	if (have > (use + 600) && have > (want + 600))
	{
		mixer.tick_add /= 2;
		//printf("[DBMIXER] Throttle due to having %d samples buffered\n", (int)have);
	}

	// Log statistics every 1 real-time second passed
	//const Bitu oldout = mixer_debug_output;
	//mixer_debug_output += ((Bitu)want << TICK_SHIFT);
	//if ((oldout / ((Bitu)44100 << TICK_SHIFT)) != (mixer_debug_output / ((Bitu)44100 << TICK_SHIFT)))
	//{
	//	printf("[DBMIXER] Output: %d - Generated: %d - Curblock: %d\n", (int)(mixer_debug_output >> TICK_SHIFT), (int)mixer_debug_generated, (int)samples);
	//	mixer_debug_output -= ((Bitu)44100 << TICK_SHIFT);
	//	mixer_debug_generated = 0;
	//}

	return (float)audio_stretch;
}

#endif
